Node.js, formidable, sharp 
==================================

This is a straightforward for file uploading.


Getting Started
---------------

```sh

# Install dependencies
npm install

# Start server
node index.js

```
